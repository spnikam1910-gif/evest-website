(function () {
  "use strict";

  /* Mobile nav toggle ------------------------------------------------ */
  var nav = document.getElementById("site-nav");
  var toggle = document.getElementById("nav-toggle");
  if (nav && toggle) {
    toggle.addEventListener("click", function () {
      var isOpen = nav.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
    // Close mobile menu after tapping a link
    nav.querySelectorAll(".nav__mobile a").forEach(function (link) {
      link.addEventListener("click", function () {
        nav.classList.remove("is-open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  /* Flash message dismiss --------------------------------------------- */
  document.querySelectorAll(".flash__close").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var flash = btn.closest(".flash");
      if (flash) flash.remove();
    });
  });
  // Auto-dismiss success/info flashes after a few seconds
  document.querySelectorAll(".flash--success").forEach(function (flash) {
    setTimeout(function () {
      flash.style.opacity = "0";
      setTimeout(function () { flash.remove(); }, 300);
    }, 6000);
  });

  /* Scroll reveal — one orchestrated moment per section, not per card - */
  var revealTargets = document.querySelectorAll(
    ".about__grid, .services__grid, .why__grid, .process__timeline, " +
    ".testimonials__grid, .faq__list, .contact__grid"
  );
  revealTargets.forEach(function (el) { el.classList.add("reveal"); });

  var heroChart = document.querySelector(".hero__chart");

  if ("IntersectionObserver" in window) {
    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );

    revealTargets.forEach(function (el) { observer.observe(el); });
    if (heroChart) observer.observe(heroChart);
  } else {
    // Fallback: show everything immediately
    revealTargets.forEach(function (el) { el.classList.add("is-visible"); });
    if (heroChart) heroChart.classList.add("is-visible");
  }

  /* Active nav link on scroll (lightweight) ---------------------------- */
  var sections = document.querySelectorAll("main section[id]");
  var navLinks = document.querySelectorAll(".nav__links a");
  if (sections.length && navLinks.length && "IntersectionObserver" in window) {
    var navObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            var id = entry.target.getAttribute("id");
            navLinks.forEach(function (link) {
              link.classList.toggle("is-active", link.getAttribute("href") === "#" + id);
            });
          }
        });
      },
      { rootMargin: "-45% 0px -50% 0px" }
    );
    sections.forEach(function (s) { navObserver.observe(s); });
  }
})();
